import sys
import itertools

def print_usage():
    print("Usage: ./game m n\n" +
              "  (m, n) are the coordinates of the starting position of the game.\n" + 
              "  Output: 1 if player 1 has a winning strategy or 2 if player 2 has a winning strategy")

# def forall_eventually(states, edges, accept_lst):
#     matches = []
#     failedMatch = False
#     for state in set(states).difference(set(accept_lst)):
#         for next_state in edges[state]:
#             if next_state not in accept_lst:
#                 failedMatch = True
#                 break
#         if not failedMatch and len(edges[state]) > 0:
#             matches.append(state)
#         else:
#             failedMatch = False
#     return matches    


def forall_next(states, edges, sat_states):
    matches = []
    failedMatch = False
    for state in set(states).difference(sat_states):
        for next_state in edges[state]:
            if next_state not in sat_states:
                failedMatch = True
                break
        if not failedMatch and len(edges[state]) > 0:
            matches.append(state)
        else:
            failedMatch = False
    return set(matches)    


def exist_next(states, edges, sat_states):
    matches = []
    for state in set(states).difference(set(sat_states)):
        for next_state in edges[state]:
            if next_state in sat_states:
                matches.append(state)
                break
    return set(matches)


# def exist_eventually(states, edges, accept_lst):
#     matches = []
#     for state in set(states).difference(set(accept_lst)):
#         for next_state in edges[state]:
#             if next_state in accept_lst:
#                 matches.append(state)
#                 break
#     return matches    


# def exist_always(states, edges, sat_states):
#     matches = []
#     failedMatch = False
#     for state in states:
#         for next_state in edges[state]:
#             if next_state in sat_states:
#                 failedMatch = True
#                 break
#         if not failedMatch and len(edges[state]) > 0:
#             matches.append(state)
#         else:
#             failedMatch = False
#     return matches  


# def model_checker(match_fn, states, edges, accept_lst, type):
#     model = set(accept_lst)
#     if type == "always":
#         sat_states = accept_lst.copy()

#     while True:
#         if type == "eventually":
#             matches = match_fn(states, edges, model)
#         elif type == "always":
#             matches = match_fn(list(model), edges, sat_states)
#             #print("matches", matches, len(matches))

#         if len(matches) == 0:
#             break

#         if type == "eventually":
#             model |= set(matches)
#         elif type == "always":
#             model = model.difference(set(matches))
#             #print("model", model)
#     return model
        

def main():
    if (len(sys.argv) != 3):
        print_usage()
        return
    
    m = sys.argv[1]
    n = sys.argv[2]
    if not m.isnumeric() or not n.isnumeric():
        print_usage()
        return
    
    m = int(m)
    n = int(n)
    states = []
    blacklist = ["1#%d#%d" % (m, n), "0#%d#%d" % (m-1, n), "0#%d#%d" % (m, n-1)] 

    for x in range(m+1):
        for y in range(n+1):
            for p in range(2):
                state = "%d#%d#%d" % (p, x, y)
                if state not in blacklist:
                    states.append(state)
    
    edges = {state: set() for state in states}
    w1sat = set(["1#0#0"])
    p1sat = set()
    p2sat = set()
    for state in states:
        p, x, y = state.split("#")
        p = int(p)
        x = int(x)
        y = int(y)
        for i in range(x):
            next_state = "%d#%d#%d" % ((p + 1) % 2, i, y)
            if next_state not in blacklist:
                edges[state].add(next_state)
        for j in range(y):
            next_state = "%d#%d#%d" % ((p + 1) % 2, x, j)
            if next_state not in blacklist:
                edges[state].add(next_state)
        for k in range(1, min(x+1, y+1)):
            next_state = "%d#%d#%d" % ((p + 1) % 2, x-k, y-k)
            if next_state not in blacklist:
                edges[state].add(next_state)

        if p == 0:
            p1sat.add(state)
        elif p == 1:
            p2sat.add(state)

    # exist next
    exist_next_sat = exist_next(states, edges, w1sat)

    p1win_sat = exist_next_sat
    L = 1
    while (L != len(p1win_sat)):
        L = len(p1win_sat)
        if "0#%d#%d" % (m, n) in p1win_sat:
            print("1")
            return

        # forall next
        forall_next_sat = forall_next(states, edges, p1win_sat)

        # exist next
        next_p1win_sat = exist_next(states, edges, forall_next_sat)
        p1win_sat = p1win_sat.union(next_p1win_sat)

    if "0#%d#%d" % (m, n) in p1win_sat:
        print("1")
    else: 
        print("2")


if __name__ == '__main__':
    main()